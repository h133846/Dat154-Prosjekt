﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DbFirstLoginLogout
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Signup_Click(object sender, EventArgs e)
        {
            using (dat154_19_3Entities db = new dat154_19_3Entities())
            {
                Customer customer = new Customer()
                {
                    Username = Username.Text,
                    Name = Name.Text,
                    Password = Password.Text
                };
                db.Customer.Add(customer);
                if (db.SaveChanges() > 0)
                {

                    smsg.ForeColor = System.Drawing.Color.Green;
                    smsg.Text = "You have registerd sucsessfully";
                }
                else
                {
                    smsg.ForeColor = System.Drawing.Color.Red;
                    smsg.Text = "Failed";
                }
            }
        }
    }
}