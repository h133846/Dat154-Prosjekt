﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DbFirstLoginLogout
{
    public partial class LoginGest : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {
            using(dat154_19_3Entities db = new dat154_19_3Entities())
            {
                if(db.Customer.Where(x => x.Username == Username.Text && x.Password == Password.Text).Count() > 0)
                {
                    Session["username"] = Username.Text;
                    Response.Redirect("Home.aspx");

                }
                else
                {
                    smsg.ForeColor = System.Drawing.Color.Red;
                    smsg.Text = "Invalid username or password";
                }
            }
        }
    }
}