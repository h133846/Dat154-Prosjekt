﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.Entity;

namespace DbFirstLoginLogout
{
    public partial class Home : System.Web.UI.Page
    {
        dat154_19_3Entities db;
        DbSet<Booking> bookings;

        protected void Page_Load(object sender, EventArgs e)
        {
            if(Session["username"].ToString() == null)
            {
                Response.Redirect("Login.aspx");
            }
            else
            {
                db = new dat154_19_3Entities();
                bookings = db.Booking;

                string username = Session["username"].ToString();
                UsernameID.Text = username;

                var bookingsUser = bookings.Where(b => b.CustomerUsername.Equals(username));

                foreach(Booking b in bookingsUser)
                {
                    ListBox1.Items.Add(b.Id + " - " + b.Room.RoomNumber + " - " + b.Customer.Name + " - " + b.CheckInDate + " - " + b.CheckOutDate + "");
                }
            }
        }

        protected void LogoutBtn_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("LoginGest.aspx");
        }

        
    }
}