﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.Entity;


namespace FrontDeskApp
{
    /// <summary>
    /// Interaction logic for ManageReservations.xaml
    /// </summary>
    public partial class ManageReservations : Window
    {
        dat154_19_3Entities dx = null;
        Booking b = null;

        public ManageReservations()
        {
            InitializeComponent();
        }

        public ManageReservations(dat154_19_3Entities dx)
        {
            this.dx = dx;
            

            InitializeComponent();

            DbSet<Room> rooms = dx.Room;

        }

        public ManageReservations(dat154_19_3Entities dx, Booking b)
        {
            this.dx = dx;
            this.b = b;
            InitializeComponent();

            gusername.Text = b.Customer.Username;
            groomnr.Text = b.Room.ToString();
            gcheckindate.SelectedDate = b.CheckInDate;
            gcheckoutdate.SelectedDate = b.CheckOutDate;
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            DbSet<Customer> customers = dx.Customer;
            DbSet<Room> rooms = dx.Room;
            
            Customer customer = customers.Where(c => c.Username.Equals(gusername.Text)).First();
            Room room = rooms.Where(r => r.RoomNumber.ToString().Equals(groomnr.Text)).First();         

            Booking b = new Booking();
            b.CustomerUsername = customer.Username;
            b.RoomId = room.RoomId;
            b.CheckInDate = gcheckindate.SelectedDate.Value;
            b.CheckOutDate = gcheckoutdate.SelectedDate.Value;

            b.Customer = customer;
            b.Room = room;

            dx.Booking.Add(b);
            dx.SaveChanges();
            gusername.Text = groomnr.Text = "";
            this.Close();
        }

        private void BDel_Click(object sender, RoutedEventArgs e)
        {
            if(b != null)
            {
                dx.Booking.Remove(b);
                dx.SaveChanges();
                gusername.Text = groomnr.Text = "";

                b = null;
                this.Close();
            }
        }

        private void BMod_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
