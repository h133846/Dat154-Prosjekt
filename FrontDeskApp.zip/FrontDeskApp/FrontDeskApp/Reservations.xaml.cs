﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.Entity;

namespace FrontDeskApp
{
    /// <summary>
    /// Interaction logic for Reservations.xaml
    /// </summary>
    public partial class Reservations : Page
    {
        MainWindow mainWindow;

        dat154_19_3Entities dx = new dat154_19_3Entities();

        DbSet<Booking> booking;
        DbSet<Customer> customer;
        DbSet<Room> room;
        DbSet<Task> task;

        public Reservations(MainWindow mainWindow)
        {
            booking = dx.Booking;
            customer = dx.Customer;
            room = dx.Room;
            task = dx.Task;

            booking.Load();
            InitializeComponent();

            bookingList.DataContext = booking.Local;
            this.mainWindow = mainWindow;
        }

        private void BookingList_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            Window w = new ManageReservations(dx, (Booking)bookingList.SelectedItem);

            w.Owner = mainWindow;
            w.ShowInTaskbar = false;
            w.ShowDialog();
        }

        private void SearchBtn_Click(object sender, RoutedEventArgs e)
        {
            bookingList.DataContext = booking.Local.Where(b => b.Customer.Name.Contains(search.Text));
        }

        private void ManageBtn_Click(object sender, RoutedEventArgs e)
        {
            new ManageReservations(dx).ShowDialog();
        }

        private void Search_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (search.Text.Length > 0)
            {

                bookingList.DataContext = booking.Local.Where(b => b.Customer.Name.Contains(search.Text));
            }
            else
            {
                bookingList.DataContext = booking.Local;
            }
        }
    }
}
